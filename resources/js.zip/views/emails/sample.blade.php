<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
    <p>Some more text {{$content['bladeData']['name']}}</p>
</body>
</html>